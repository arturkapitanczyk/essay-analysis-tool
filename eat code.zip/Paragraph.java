
package javaapplication3;

import static javaapplication3.UI.essays;
import javax.swing.JPanel;


public class Paragraph extends Statistic
{
    Paragraph(JPanel panelP)
    {
        setPanel(panelP);
        setBarChartTitle("Paragraph number vs Grades");
        setXAxisLabel("Grade");
        setYAxisLabel("Paragraph number");
    }
    @Override
    public int getStatistic(String name) 
    {
        Essay essay = new Essay();
        int indexOfNumber = essay.getIndexOfEssay(name);
        int numOfParagraphs = essays.get(indexOfNumber).getNumOfParagraphs();
        
        return numOfParagraphs;
    }
    

    

    
}
