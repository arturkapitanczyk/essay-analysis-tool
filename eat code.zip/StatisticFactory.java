/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication3;

import javax.swing.JPanel;


public class StatisticFactory 
{
    public static WordVariety createWordVarietyChart()
    {
        WordVariety chart = new WordVariety();
        return chart;
    }
    
    public static WordCount createWordCountChart(JPanel panel)
    {
        WordCount chart = new WordCount(panel);
        return chart;
    }
    
    public static Quotes createQuoteChart(JPanel panel)
    {
        Quotes chart = new Quotes(panel);
        return chart;
    }
    
    public static Paragraph createParagraphChart(JPanel panel)
    {
        Paragraph chart = new Paragraph(panel);  
        return chart;
    }
    
    public static FirstPerson createFirstPersonChart(JPanel panel)
    {
        FirstPerson chart = new FirstPerson(panel);
        return chart;
    }
    
    public static MostCommonWords createMostCommonWordsTable()
    {
        MostCommonWords table = new MostCommonWords();
        return table;
    }
}
