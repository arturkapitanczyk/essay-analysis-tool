
package javaapplication3;

public class InvalidGrade extends Exception
{
    InvalidGrade()
    {
        super();
    }
    
    InvalidGrade(String error)
    {
        super(error);
    }
}
