
package javaapplication3;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.StringTokenizer;
import static javaapplication3.UI.essays;
import javax.swing.JInternalFrame;
import javax.swing.JOptionPane;
import org.tartarus.snowball.EnglishSnowballStemmerFactory;
import org.tartarus.snowball.util.StemmerException;


public class Essay
{

    
    private String name;
    private int grade;
    private int numOfParagraphs;
    
    public String getName()
    {
        return this.name;
    }
    
    public int getGrade()
    {
        return this.grade;
    }
    
    public int getNumOfParagraphs()
    {
        return this.numOfParagraphs;
    }
    
    public void setName(String newName)
    {
        this.name =  newName;
    }
    
    public void setGrade(int newGrade)
    {
        this.grade = newGrade;
    }

    public void setNumOfParagraphs(int newNumOfParagraphs)
    {
        this.numOfParagraphs = newNumOfParagraphs;
    }
    
    private void storeEssay(String text, String essayName)
    {
        ArrayList<String> essayWords = new ArrayList<String>();
        StringTokenizer wordSeparator = new StringTokenizer(text," ");
        while (wordSeparator.hasMoreTokens()){
            String Word = wordSeparator.nextToken();
            String noPunctuationInWord = Word.replaceAll("[^a-zA-Z ]", "");
            String wordToLowerCase = noPunctuationInWord.toLowerCase();
            try {
                String stemmedWord = EnglishSnowballStemmerFactory.getInstance().process(wordToLowerCase);
                essayWords.add(stemmedWord);
            } catch (StemmerException ex) {}   
        }
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(essayName+"WordStorageFile.txt"));
            for (int k = 0; k < essayWords.size(); k++)
            {
                writer.println(essayWords.get(k));
            }
            writer.close();
        } catch (IOException ex) {}
        try {
            PrintWriter writer = new PrintWriter(new FileWriter(essayName+"OriginalStorageFile.txt"));
            writer.println(text);
            writer.close();
        } catch (IOException ex) {}      
    }

    public void saveEssayNames() throws IOException
    {   
        File file;
        if (essays.size() > 0)
        {           
            PrintWriter writer = new PrintWriter(new BufferedWriter(new FileWriter("EssayNamesStorageFile.txt")));
            String tmp = "";
            for (int er = 0; er < essays.size();er++)
            {               
                tmp = essays.get(er).name;
                writer.println(tmp);
                writer.flush();              
            }
            writer.close();
        }
        else
        {
            file = new File("EssayNamesStorageFile.txt");
            file.delete();
            file.createNewFile();
        }
    }
    
    public void saveEssayNumOfParagraphs() throws IOException
    {
        File file;
        if (essays.size() > 0)
        {           
            PrintWriter Writer = new PrintWriter(new BufferedWriter(new FileWriter("EssayParagraphStorageFile.txt")));
            int intTmp = 0;
            for (int ere = 0; ere < essays.size();ere++)
            {
                
                intTmp = essays.get(ere).numOfParagraphs;
                Writer.println(intTmp);
                Writer.flush();
                
                
            }
            Writer.close();
        }
        else
        {
            file = new File("EssayParagraphStorageFile.txt");
            file.delete();
            file.createNewFile();
        }
    }
    
    
    
    
    
    public void saveEssayGrades() throws IOException
    {   
        File file;
        if (essays.size() > 0)
        {           
            PrintWriter Writer = new PrintWriter(new BufferedWriter(new FileWriter("EssayGradesStorageFile.txt")));
            int intTmp = 0;
            for (int rr = 0; rr < essays.size();rr++)
            {
                
                intTmp = essays.get(rr).grade;
                Writer.println(intTmp);
                Writer.flush();
                
                
            }
            Writer.close();
        }
        else
        {
            file = new File("EssayGradesStorageFile.txt");
            file.delete();
            file.createNewFile();
        }
    }
    
    
    
    
    
    public void storeEssay(String tmp, String tmpN, String tmpG, JInternalFrame iF, int tmpP) throws EssayAlreadyExistsException, InvalidGrade
    {
        for (int h = 0; h<essays.size();h++) {
            if (tmpN.equals(essays.get(h).name)){                
                throw new EssayAlreadyExistsException("The essay name has already been used");                
            }    
        }
        Essay essay = new Essay();
        int intTmp = Integer.parseInt(tmpG);
        essay.name = tmpN;
        essay.grade = intTmp;
        essay.numOfParagraphs = tmpP;
        essays.add(essay);
        storeEssay(tmp,tmpN);
        JOptionPane.showMessageDialog(iF, "Essay has been saved");
    }
    
    public int getIndexOfEssay(String essayName)
    {
        int indexOfEssay = 0;
        for (int i = 0; i < essays.size(); i++)      
            if (essays.get(i).name.equals(essayName))
                indexOfEssay = i;   
        return indexOfEssay;
    }
    
    public void removeEssay(String EssayName, Paragraph paragraph, MostCommonWords mostcommonwords, FirstPerson firstperson) throws IOException
    {
        File file;
        int intTmp = getIndexOfEssay(EssayName);
        String tmp = essays.get(intTmp).name;
        essays.remove(getIndexOfEssay(EssayName));
        saveEssayNames();
        saveEssayGrades();
        saveEssayNumOfParagraphs();
        
        file = new File(intTmp+".txt");
        file.delete();
        file = new File(tmp+"WordStorageFile.txt");
        file.delete();
        file = new File(tmp+"OriginalStorageFile.txt");
        file.delete();
    }
    
    
    public void addStoredToEssays() throws FileNotFoundException, IOException
    {
        String tmp;
        ArrayList<Integer> tmpEssayGrades = new ArrayList<Integer>();
        ArrayList<String> tmpEssayNames = new ArrayList<String>();
        ArrayList<Integer> tmpNumsOfParagraphs = new ArrayList<Integer>();
        BufferedReader reader = new BufferedReader(new FileReader("EssayGradesStorageFile.txt")); 
        int intTmp = 0;
        while ((tmp = reader.readLine()) != null){
             intTmp = Integer.parseInt(tmp);
             tmpEssayGrades.add(intTmp);
        }
        reader.close();
        reader = new BufferedReader(new FileReader("EssayNamesStorageFile.txt")); 
        while ((tmp = reader.readLine()) != null){
            tmpEssayNames.add(tmp);
        }
        reader.close();      
        reader = new BufferedReader(new FileReader("EssayParagraphStorageFile.txt")); 
        intTmp = 0;
        while ((tmp = reader.readLine()) != null){
             intTmp = Integer.parseInt(tmp);
             tmpNumsOfParagraphs.add(intTmp);
        }
        reader.close();
        for (int i = 0; i < tmpEssayNames.size(); i++){
            Essay essay = new Essay();
            essay.name = tmpEssayNames.get(i);
            essay.grade = tmpEssayGrades.get(i);
            essay.numOfParagraphs = tmpNumsOfParagraphs.get(i);
            essays.add(essay);
        }
    }
}
