
package javaapplication3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import static javaapplication3.UI.essays;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;


public class WordVariety 
{
    
    public void showWordVarietyChart(JPanel panel)
    {
        DefaultCategoryDataset barChartWordVarietyData = new DefaultCategoryDataset();
            try 
            {
                for (int ii = 01; ii<8;ii++)
                    barChartWordVarietyData.setValue(getAverageWordVarietyForGrade(ii), "Word Variety", Integer.toString(ii));       
                JFreeChart chartWordVariety = ChartFactory.createBarChart("Word Variety vs Grades", "Grade", "Word Variety", barChartWordVarietyData, PlotOrientation.VERTICAL, false, true, false);
                CategoryPlot plotterWordVariety = chartWordVariety.getCategoryPlot();
                plotterWordVariety.setRangeGridlinePaint(Color.ORANGE);
        ChartPanel barPanelWordVariety = new ChartPanel(chartWordVariety);
        panel.removeAll();
        panel.add(barPanelWordVariety,BorderLayout.CENTER);
        panel.validate();
            } catch (FileNotFoundException ex) {
            }
    }
    
    public String[][] getEssayWordVariety(String name) throws FileNotFoundException
    {
        String[][] uniqueWordsAndCount = {};
        String tmp = "";
        ArrayList<String> uniqueWords = new ArrayList<String>();
        BufferedReader reader = new BufferedReader(new FileReader(name+"WordStorageFile.txt")); 
        try{
            while ((tmp = reader.readLine()) != null){
                if (!uniqueWords.contains(tmp))
                    uniqueWords.add(tmp);
            }
            reader.close();
            int[] uniqueWordCount = new int[uniqueWords.size()];
            for (int q = 0;q<uniqueWordCount.length;q++)
                uniqueWordCount[q] = 0;
            for (int d = 0;d<uniqueWords.size();d++){               
                reader = new BufferedReader(new FileReader(name+"WordStorageFile.txt"));
                String checker = uniqueWords.get(d);
                while ((tmp = reader.readLine()) != null){
                    if (checker.equals(tmp))
                        uniqueWordCount[d]++;
                }
                reader.close();
            }
            reader.close(); 
            uniqueWordsAndCount = new String[uniqueWords.size()][2];
            for (int r = 0;r<uniqueWordCount.length;r++){
                uniqueWordsAndCount[r][0] = uniqueWords.get(r);
                uniqueWordsAndCount[r][1] = Integer.toString(uniqueWordCount[r]); 
            }
        }     
        catch (IOException ex){
        }
        return uniqueWordsAndCount;
    }
    
    private int getAverageWordVarietyForGrade (int grade) throws FileNotFoundException
    {
        int averageWordVarietyForGrade = 0;
        ArrayList<Integer> numsOfUniqueWordsPerGrade = new ArrayList<Integer>();
        String[][] tmp = {};
        if (((grade >= 1) || (grade <= 7)))
        { 
            int numOfUniqueWords = 0;
            for (int yy = 0;yy < essays.size();yy++)
            {
                if (grade == essays.get(yy).getGrade())
                {
                    tmp = getEssayWordVariety(essays.get(yy).getName());
                    numOfUniqueWords = tmp.length;
                    numsOfUniqueWordsPerGrade.add(numOfUniqueWords);
                }
            }
            for (int tt = 0;tt<numsOfUniqueWordsPerGrade.size();tt++)
            {
                averageWordVarietyForGrade += numsOfUniqueWordsPerGrade.get(tt);
            }
            try
            {
            averageWordVarietyForGrade = averageWordVarietyForGrade / numsOfUniqueWordsPerGrade.size();
            }
            catch (Exception ex)
            {
                averageWordVarietyForGrade = 0;
            }
        }
        return averageWordVarietyForGrade;
    }
}
