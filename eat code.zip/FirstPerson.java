
package javaapplication3;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JPanel;

public class FirstPerson extends Statistic
{
    FirstPerson(JPanel panelP)
    {
        setPanel(panelP);
        setBarChartTitle("First person used vs Grades");
        setXAxisLabel("Grade");
        setYAxisLabel("First person used");
    }

    private final String[] firstPersonWords = {"i","my","me","we","us","our",};


    
    
    private boolean isFirstPersonUsed(String word)
    {
        for (int i = 0;i < firstPersonWords.length;i++) {
            if (word.equals(firstPersonWords[i])) {
                return true;
            }
        }
        return false;
    }
    
  
    
    
    
    private ArrayList<String> getAllWords(String name) throws FileNotFoundException
    {
        ArrayList<String> essayWords;
        String tmp;
        essayWords = new ArrayList<String>();
        BufferedReader essayStoreReader = new BufferedReader(new FileReader(name+"WordStorageFile.txt")); 
        try {
            while ((tmp = essayStoreReader.readLine()) != null)
            {
                essayWords.add(tmp);
            }
            essayStoreReader.close();
        }catch (IOException ex){
        }
        return essayWords;
    }

    @Override
    public int getStatistic(String name) 
    {
        ArrayList<String> essayWords = new ArrayList<String>();
        try {
            essayWords = getAllWords(name);
        } catch (FileNotFoundException ex) {
        }
        int numberOfFirstPersonUsed = 0;
        for (int i = 0;i < essayWords.size();i++) {
            String tmp = (String) essayWords.get(i);
            if (isFirstPersonUsed(tmp))
                numberOfFirstPersonUsed++;
        } 
        return numberOfFirstPersonUsed;
    }
}
