package javaapplication3;

public class EssayAlreadyExistsException extends Exception
{
    EssayAlreadyExistsException()
    {
        super();
    }
    
    EssayAlreadyExistsException(String error)
    {
        super(error);
    }
}

