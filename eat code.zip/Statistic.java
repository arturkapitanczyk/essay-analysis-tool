
package javaapplication3;

import java.awt.BorderLayout;
import java.awt.Color;
import java.io.IOException;
import java.util.ArrayList;
import static javaapplication3.UI.essays;
import javax.swing.JPanel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;

public abstract class Statistic 
{
    private JPanel panel;
    private String barChartTitle;
    private String xAxisLabel;
    private String yAxisLabel;
    
    public void setPanel(JPanel panelP)
    {
        this.panel = panelP;
    }
    
    public void setBarChartTitle(String barChartTitleB)
    {
        this.barChartTitle = barChartTitleB; 
    }
    
    public void setXAxisLabel(String xAxisLabelX)
    {
        this.xAxisLabel = xAxisLabelX;
    }
    
    public void setYAxisLabel(String yAxisLabelY)
    {
        this.yAxisLabel = yAxisLabelY;
    }
    
    public void showChart()
    {
        DefaultCategoryDataset barChartData = new DefaultCategoryDataset();     
        for (int ii = 01; ii<8;ii++)       
            try 
            {
                barChartData.setValue(getAverage(ii), "", Integer.toString(ii));
                JFreeChart chart = ChartFactory.createBarChart(barChartTitle, xAxisLabel, yAxisLabel, barChartData, PlotOrientation.VERTICAL, false, true, false);
                CategoryPlot plotter = chart.getCategoryPlot();
                plotter.setRangeGridlinePaint(Color.BLUE);
                ChartPanel barPanel = new ChartPanel(chart);
                panel.removeAll();
                panel.add(barPanel,BorderLayout.CENTER);
                panel.validate();
            }
            catch (IOException ex) {
                
            }
    }
    
    public int getAverage(int grade) throws IOException
    {
        int averageNumberForGrade = 0;
        if (((grade >= 1) || (grade <= 7)))
        { 
            averageNumberForGrade = 0;
            ArrayList<Integer> numsOfNumbersPerGrade = new ArrayList<Integer>();
            for (int yy = 0;yy < essays.size();yy++)
            {
                if (grade == essays.get(yy).getGrade())
                {
                    int intTmp = getStatistic(essays.get(yy).getName());
                    numsOfNumbersPerGrade.add(intTmp);
                }
            }
            for (int tt = 0;tt<numsOfNumbersPerGrade.size();tt++)
            {
                averageNumberForGrade += numsOfNumbersPerGrade.get(tt);
            }
            try
            {
            averageNumberForGrade = averageNumberForGrade / numsOfNumbersPerGrade.size();
            }
            catch (Exception ex)
            {
                averageNumberForGrade = 0;
            }
        }
        return averageNumberForGrade;
    }
    
    public abstract int getStatistic(String name);
}
