
package javaapplication3;

import java.io.FileNotFoundException;
import static javaapplication3.UI.essays;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;

public class MostCommonWords
{
    private String[] commonWords = {"the", "is", "a", "an","of","as","about","at","by","in","for","on","to",""," ","and","his","her"};   
    public void showMostCommonWordsTable(JTable table)
    {
        String[] mostCommonWords = new String[7];
        DefaultTableModel model = (DefaultTableModel) table.getModel();       
        for (int o =0;o < model.getRowCount();o++)
        {
            model.removeRow(o);
            table.validate();
        }
        for (int i = 1;i < 8;i++)
        {
            String mostCommonWord = "";
            int mostCommonWordValue = 0;
            for (int yy = 0;yy < essays.size();yy++)
            {
                if (i == essays.get(yy).getGrade())
                {
                    try 
                    {
                        WordVariety wordvariety = new WordVariety();
                        String[][] tmp = wordvariety.getEssayWordVariety(essays.get(yy).getName());                    
                        for (int b = 0;b < tmp.length;b++)
                        {
                            int intTmp = Integer.parseInt(tmp[b][1]);
                            if ((intTmp > mostCommonWordValue) && (!(isCommonWord(tmp[b][0]))))
                            {
                                mostCommonWordValue = intTmp;
                                int indexOfMostCommon = b;
                                mostCommonWord = tmp[b][0];
                            }                           
                        }
                    } 
                    catch (FileNotFoundException ex){  
                    }                  
                }         
            }
            mostCommonWords[i-1] = mostCommonWord;
        }
        
        model.insertRow(model.getRowCount(), mostCommonWords);
        table.validate();
        
    }
    private boolean isCommonWord(String word)
    {
        for (int i = 0;i < commonWords.length;i++)
        {
            if (word.equals(commonWords[i]))
                return true;   
        }
        return false;
        
    }
}
