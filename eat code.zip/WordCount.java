
package javaapplication3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import javax.swing.JPanel;

public class WordCount extends Statistic
{
    WordCount(JPanel panelP)
    {
        setPanel(panelP);
        setBarChartTitle("Word count vs Grades");
        setXAxisLabel("Grade");
        setYAxisLabel("Word count");
    }
    @Override
    public int getStatistic(String name) 
    {
        String tmp;
        ArrayList<String> essayWords = new ArrayList<String>();
        BufferedReader essayStoreReader; 
        try {
            essayStoreReader = new BufferedReader(new FileReader(name+"WordStorageFile.txt"));
            while ((tmp = essayStoreReader.readLine()) != null)
            {
                essayWords.add(tmp);
            }
            essayStoreReader.close();
        } catch (IOException ex) {
        }
        return essayWords.size();
    }
}
