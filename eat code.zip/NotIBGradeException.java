
package javaapplication3;


public class NotIBGradeException extends Exception
{
    NotIBGradeException()
    {
        super();
    }
    
    NotIBGradeException(String error)
    {
        super(error);
    }
}
