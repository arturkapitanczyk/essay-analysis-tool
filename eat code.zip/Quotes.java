
package javaapplication3;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JPanel;


public class Quotes extends Statistic
{
    Quotes(JPanel panelP)
    {
        setPanel(panelP);
        setBarChartTitle("Quote number vs Grades");
        setXAxisLabel("Grade");
        setYAxisLabel("Quote number");
    }
    
    


    @Override
    public int getStatistic(String name) 
    {
        String tmp;
        char[] essayCharArray;
        int numberOfQuotationMarks = 0;
        int numberOfQuotes = 0;
        //step 1 - loading the essay string from storage .txt files
        BufferedReader essayOriginalStoreReader;
        try {
            essayOriginalStoreReader = new BufferedReader(new FileReader(name + "OriginalStorageFile.txt"));   
        String text =  essayOriginalStoreReader.readLine();
        while ((tmp = essayOriginalStoreReader.readLine()) != null){
                    text += tmp;
                }
        essayOriginalStoreReader.close();   
        //step 2 - counts the quotation marks and assumes two quotation marks mean a quote
        essayCharArray = text.toCharArray();
        for (int i = 0;i < essayCharArray.length;i++){
            if ((essayCharArray[i] == '"' )|| (essayCharArray[i] == '”') || (essayCharArray[i] == '“')){
                numberOfQuotationMarks++;
            }
            if (numberOfQuotationMarks == 2){
                numberOfQuotes++;
                numberOfQuotationMarks = 0;
            }
        }
        } catch (IOException ex) {
        }
        //return statement
        return numberOfQuotes;
    }
}
